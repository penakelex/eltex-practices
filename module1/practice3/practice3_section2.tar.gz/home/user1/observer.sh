#!/bin/bash

CONFIG_FILE="$HOME/observer.conf"
LOG_FILE="$HOME/observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Файл конфигурации $CONFIG_FILE не найден!"
    exit 1
fi

# Читаем файл конфигурации построчно
while IFS= read -r script; do
    # Пропускаем пустые строки
    [ -z "$script" ] && continue
    
    # Проверяем, запущен ли скрипт. 
    # pgrep -f ищет совпадение по полной командной строке в /proc
    if ! pgrep -f "$script" > /dev/null; then
        # Если не запущен - запускаем через nohup в фоне
        nohup "$script" > /dev/null 2>&1 &
        # Пишем в лог
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапущен скрипт: $script" >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"
