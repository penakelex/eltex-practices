#!/bin/bash

for arg in "$@"; do
    case $arg in
        --pishitesuda=*)
        PIPE_PATH="${arg#*=}"
        shift
        ;;
    esac
done

if [ -z "$PIPE_PATH" ]; then
    echo "Ошибка: не указан путь к каналу (--pishitesuda=/path/to/pipe)"
    exit 1
fi

LOG_FILE="$HOME/cuckoo.log"
mkfifo "$PIPE_PATH"

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

cleanup() {
    log_msg "Shutdown!"
    rm -f "$PIPE_PATH"
    exit 0
}

trap cleanup SIGTERM SIGINT

log_msg "Startup!"

while true; do
    if read -r request < "$PIPE_PATH"; then
        if [[ "$request" =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            N=$(( RANDOM % 9 + 2 ))
            echo "$N" > "$PIPE_PATH"
            log_msg "$NAME[$PID] $N"
        fi
    fi
done
