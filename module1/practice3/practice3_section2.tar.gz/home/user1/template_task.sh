#!/bin/bash

SCRIPT_NAME=$(basename "$0")
CUCKOO_PIPE="/tmp/cuckoo_pipe"

if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

LOG_FILE="report_${SCRIPT_NAME}.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

echo "${SCRIPT_NAME}[$$]: how much time do I have?" > "$CUCKOO_PIPE"

read -r N < "$CUCKOO_PIPE"

if [[ "$N" =~ ^[0-9]+$ ]]; then
    sleep "$N"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Ошибка: не получено время от cuckoo" >> "$LOG_FILE"
fi
